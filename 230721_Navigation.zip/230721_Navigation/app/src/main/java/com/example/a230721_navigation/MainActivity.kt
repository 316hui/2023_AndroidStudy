package com.example.a230721_navigation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.a230721_navigation.databinding.ActivityMainBinding


private const val TAG_CALENDER = "calender_fragment"
private const val TAG_HOME = "home_fragment"
private const val TAG_MY_PAGE = "my_page_fragment"
private const val TAG_ADD = "add_fragment"

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setFragment (TAG_HOME, HomeFragment())
        binding.navigationView.selectedItemId = R.id.homeFragment

        binding.navigationView.setOnItemSelectedListener { item ->
            when(item.itemId) {
                R.id.calenderFragment -> setFragment(TAG_CALENDER, CalenderFragment())
                R.id.homeFragment -> setFragment(TAG_HOME, HomeFragment())
                R.id.myPageFragment -> setFragment(TAG_MY_PAGE, MyPageFragment())
                R.id.addFragment -> setFragment(TAG_ADD, addFragment())
            }
            true
        }
    }

    private fun setFragment(tag: String, fragment: Fragment) {
        val manager: FragmentManager = supportFragmentManager
        val fragTransaction = manager.beginTransaction()

        if (manager.findFragmentByTag(tag) == null){
            fragTransaction.add(R.id.mainFrameLayout, fragment, tag)
        }

        val calender = manager.findFragmentByTag(TAG_CALENDER)
        val home = manager.findFragmentByTag(TAG_HOME)
        val myPage = manager.findFragmentByTag(TAG_MY_PAGE)
        val add = manager.findFragmentByTag(TAG_ADD)

        if (calender != null) {
            fragTransaction.hide(calender)
        }
        if (home != null) {
            fragTransaction.hide(home)
        }
        if (myPage != null) {
            fragTransaction.hide(myPage)
        }
        if (add != null) {
            fragTransaction.hide(add)
        }

        if (tag == TAG_CALENDER) {
            if (calender != null) {
                fragTransaction.show(calender)
            }
        }
        else if (tag == TAG_HOME) {
            if (home != null) {
                fragTransaction.show(home)
            }
        }
        else if (tag == TAG_MY_PAGE){
            if (myPage != null) {
                fragTransaction.show(myPage)
            }
        }
        else if (tag == TAG_ADD) {
            if (add != null) {
                fragTransaction.show(add)
            }
        }

        fragTransaction.commitAllowingStateLoss()
            //액티비티의 상태를 저장하지 않도록 사용할 수 있다. 이렇게 하면 Fragment의 상태 변화만 반영.
    }
}