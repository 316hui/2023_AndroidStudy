package com.example.calculate

import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.calculate.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val binding: ActivityMainBinding by lazy{ ActivityMainBinding.inflate(layoutInflater) }

    //뷰
    private val resultTextView: TextView by lazy {
        findViewById<TextView>(R.id.result)
    }

    //플래그
    private var isOperator = false
    private var hasOperator = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }


    // 클릭 이벤트 처리
    fun buttonClicked(v: View){
        when (v.id) {
            R.id.button0 -> numberButtonClicked("0")
            R.id.button00 -> numberButtonClicked("00")
            R.id.button1 -> numberButtonClicked("1")
            R.id.button2 -> numberButtonClicked("2")
            R.id.button3 -> numberButtonClicked("3")
            R.id.button4 -> numberButtonClicked("4")
            R.id.button5 -> numberButtonClicked("5")
            R.id.button6 -> numberButtonClicked("6")
            R.id.button7 -> numberButtonClicked("7")
            R.id.button8 -> numberButtonClicked("8")
            R.id.button9 -> numberButtonClicked("9")
            R.id.buttondot -> numberButtonClicked(".")

            R.id.buttonplus -> operatorButtonClicked("+")
            R.id.buttonminus -> operatorButtonClicked("-")
            R.id.buttonmulti -> operatorButtonClicked("X")
            R.id.buttondiv -> operatorButtonClicked("/")

        }
    }

    private fun numberButtonClicked(number: String) {
        if (isOperator) {
            resultTextView.append(" ")
        }
        isOperator = false

        resultTextView.append(number)
       // resultTextView.text = calculateExpression()
    }
    //연산자 버튼 클릭 처리
    private fun operatorButtonClicked(operator: String) {
        if (resultTextView.text.isEmpty()) {
            return
        }

        when {
            isOperator -> {
                val text = resultTextView.text.toString()
//                expressionTextView.text = text.dropLast(1) + operator
            }
            else -> {
                resultTextView.append(" $operator")
            }

        }

        // SpannableStringBuilder를 사용하여 마지막 연산자의 색상 변경
        val ssb = SpannableStringBuilder(resultTextView.text)
        ssb.setSpan(
            ForegroundColorSpan(getColor(R.color.purple_200)),
            resultTextView.text.length - 1, resultTextView.text.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        resultTextView.text = ssb

        isOperator = true
        hasOperator = true
    }

fun resultButtonClicked(v:View) {
    val expressionTexts = resultTextView.text.split(" ")
    if (resultTextView.text.isEmpty() || expressionTexts.size == 1) {
        return
    }

    val resultText = calculateExpression()

    resultTextView.text = ""
    resultTextView.text = resultText

    isOperator = false
    hasOperator = false
}

private fun calculateExpression(): String{
    val expressionTexts = resultTextView.text.split(" ")

    if (hasOperator.not() || expressionTexts.size != 3) {
        return ""
    } else if (expressionTexts[0].isNumber().not() || expressionTexts[2].isNumber().not()) {
        return ""
    }
    val exp1 = expressionTexts[0].toBigInteger()
    val exp2 = expressionTexts[2].toBigInteger()

    return when (expressionTexts[1]) {
        "+" -> (exp1 + exp2).toString()
        "-" -> (exp1 - exp2).toString()
        "X" -> (exp1 * exp2).toString()
        "%" -> (exp1 % exp2).toString()
        "/" -> (exp1 / exp2).toString()
        else -> ""
    }
}

fun clearButtonClicked(v : View) {
    resultTextView.text = ""
    resultTextView.text = ""
    isOperator = false
    hasOperator = false
   }
}

fun String.isNumber(): Boolean {
    return try {
        this.toBigInteger()
        true
    } catch (e: NumberFormatException) {
        false
    }
}