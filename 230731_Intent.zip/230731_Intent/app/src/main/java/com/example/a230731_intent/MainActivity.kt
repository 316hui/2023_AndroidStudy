package com.example.a230731_intent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a230731_intent.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        //해당 레이아웃 파일의 뷰를 인플레이션하여 바인딩 객체를 만드는 코드 , 레이아웃 인플레이터를 받아옴
        setContentView(binding.root)

        binding.intentButton.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            //첫 번째 매개변수인 this는 현재 컨텍스트(Context)를 의미, 액티비티에서 인텐트를 생성하는 것을 의미.
            // 두 번째 매개변수인 SubActivity::class.java는 전환하고자 하는 액티비티의 클래스 이름을 지정합니다.
            // 즉, MainActivity2라는 액티비티로 전환하도록 하는 명시적 인텐트를 생성
            startActivity(intent)
        }
    }
}


