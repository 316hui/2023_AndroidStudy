package com.example.a230731_intent

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a230731_intent.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {

    private lateinit var binding : ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.closeButton.setOnClickListener{
            finish()
        }



    }
}