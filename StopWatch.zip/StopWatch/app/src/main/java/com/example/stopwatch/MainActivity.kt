package com.example.stopwatch

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.webkit.WebView
import android.widget.Button
import android.widget.Chronometer
import android.widget.TextClock
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    lateinit var startBtn: Button
    lateinit var stopBtn: Button
    lateinit var resetBtn: Button
    val TAG = "로그"

    var running: Boolean = false //상태
    var pauseTime = 0L //멈춤 시간

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG, "onCreate: called")


        val clock:TextClock = findViewById<TextClock>(R.id.clock)

        clock.format12Hour = "yyyy-MM-dd hh:mm:ss a"
        
        val chronometer : Chronometer = findViewById (R.id.chronometer)
        startBtn = findViewById(R.id.startBtn)
        stopBtn = findViewById(R.id.stopBtn)
        resetBtn = findViewById(R.id.resetBtn)

        //화면 설정
        viewMode("stop")



        startBtn.setOnClickListener {
            if (!running) {
                chronometer.base = SystemClock.elapsedRealtime() - pauseTime

                //시작
                chronometer.start()

                viewMode("start")
            }
        }

        resetBtn.setOnClickListener {
            //정지 상태

                chronometer.base = SystemClock.elapsedRealtime()

                //시작
                pauseTime = 0L

                chronometer.stop()

                viewMode("stop")

        }

        stopBtn.setOnClickListener {
            //기본 세팅
//            chronometer.base = SystemClock.elapsedRealtime()

            //정지 시간 초기화
//            Log.d("","${SystemClock.elapsedRealtime()}\n${chronometer.base}")
            pauseTime = SystemClock.elapsedRealtime() - chronometer.base

            //정지

            chronometer.stop()


            //화면설정
            viewMode("stop")
        }

        val placeButton : Button
        placeButton = findViewById(R.id.placeButton)

        placeButton.setOnClickListener {
            var intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://ticket.interpark.com/"))
            startActivity(intent)

        }

        initClickWebView() //oncreate 안에 넣기
    }
    //oncreate



    private fun initClickWebView() {
        val myWebView: WebView = findViewById(R.id.webview_login)
        myWebView.loadUrl("https://mticket.interpark.com/") //보여주기용
    }
////        myWebView.setOnClickListener {
////            Log.d(TAG, "initClickWebView: called") //로그찍기
////            val browserIntent =
////                Intent(Intent.ACTION_VIEW, Uri.parse("https://mticket.interpark.com/"))
////            startActivity(browserIntent)
////
////        }
//    }



    private fun viewMode(mode: String) {

        if (mode == "start") {
            startBtn.isEnabled = false
            stopBtn.isEnabled = true
            resetBtn.isEnabled = true
            running = true
        } else {
            startBtn.isEnabled = true
            stopBtn.isEnabled = false
            resetBtn.isEnabled = true
            running = false
        }
    }



}
