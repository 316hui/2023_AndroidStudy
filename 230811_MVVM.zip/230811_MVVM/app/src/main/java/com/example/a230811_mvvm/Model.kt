package com.example.a230811_mvvm

class Model {
    var password : MutableList<Int> = mutableListOf()
    //변형 가능한 password 리스트 생성

    fun inputPassword(i : Int) {
        if (password.size < 4) {
            password.add(i)
        }
    }
    fun checkPassword() : Boolean {
        var trueCount = 0
        var savePassword = mutableListOf(1, 2, 3, 4)

        for (i in 0 until savePassword.size) {
            if (savePassword.get(i) == password.get(i)) {
                trueCount += 1
            }
        }

        return trueCount == 4
    }
}