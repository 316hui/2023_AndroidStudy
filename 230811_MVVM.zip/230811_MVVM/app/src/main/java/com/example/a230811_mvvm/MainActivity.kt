package com.example.a230811_mvvm

import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.example.a230811_mvvm.R
import com.example.a230811_mvvm.databinding.ActivityMainBinding

//controller
class MainActivity : AppCompatActivity(){
    private lateinit var binding : ActivityMainBinding



    var viewModel = ViewModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        //데이터바인딩을 사용해 현재 액티비티 컨텐츠뷰로 설정. 바인딩 -> UI요소와 액티비티 코드를 연결하는 객체가 됨.

        binding.viewModel = viewModel
        viewModel.toastMessage.observe(this, Observer {
            Toast.makeText(this, "$it 번을 클릭했습니다", Toast.LENGTH_SHORT).show()
        })
        
        viewModel.checkPassWordMessage.addOnPropertyChangedCallback(object : Observable.OnPropertyChangedCallback(){
            override fun onPropertyChanged(sender: Observable?, propertyId: Int) {
                if (viewModel.checkPassWordMessage.get() == true){
                    binding.messageSuccess.visibility = View.VISIBLE
                }else {
                    binding.messageSuccess.visibility = View.GONE
                }

            }

        })
    }

}