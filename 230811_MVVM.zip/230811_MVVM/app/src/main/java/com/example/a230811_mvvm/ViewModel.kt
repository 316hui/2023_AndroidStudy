package com.example.a230811_mvvm

import android.database.Observable
import androidx.databinding.ObservableField
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer

class ViewModel {
    //뷰 인터페이스 기능을 여기로
    var toastMessage = MutableLiveData<Int>()
    var checkPassWordMessage = ObservableField<Boolean>(false)
    // ObservableField: 사용하면 데이터 변경을 감지하고 UI 업데이트를 자동으로 처리

    var model = Model()


    //presenter 역할을 여기로 다 가져옴 (뷰와 모델을 이음)
    fun clickNumber (i: Int) {
        toastMessage.value = i
        model.inputPassword(i)

        if (model.password.size == 4 && model.checkPassword()){
            //모델에 있는 패스워드 리스트 길이가 4이고, 모델의 비밀번호 체크하는 함수가 참일때.
            checkPassWordMessage.set(true)

        }
    }
}