package com.example.a230811_mvvm

import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.a230811_mvvm.R
import com.example.a230811_mvvm.databinding.ActivityMainBinding

//controller
class MainActivity : AppCompatActivity(), ViewInterface {

    private lateinit var binding : ActivityMainBinding

    var presenter = Presenter(this)
        //this: 현 클래스, 여기선 현 클래스의 ViewInterface를 뜻함.

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        //데이터바인딩을 사용해 현재 액티비티 컨텐츠뷰로 설정. 바인딩 -> UI요소와 액티비티 코드를 연결하는 객체가 됨.

        binding.mainActivity = this
        //데이터 바인딩으로 레이아웃을 변수랑 연결, mainActivity 변수를 현재 액티비티 객체로 설정.
        //레이아웃파일 mainActivity를 현재 액티비티 객체와 연결.
    }

    fun clickNumber (i: Int) {
        presenter.clickNumber(i)
        //클릭했을 때 무엇을 클릭했는지 넘겨줌.
    }

    override fun toastMessage(i: Int) {
        Toast.makeText(this, "$i 번을 클릭했습니다.", Toast.LENGTH_SHORT).show()
    }

    override fun checkPassWordMessage() {
        binding.messageSuccess.visibility = View.VISIBLE
    }


}