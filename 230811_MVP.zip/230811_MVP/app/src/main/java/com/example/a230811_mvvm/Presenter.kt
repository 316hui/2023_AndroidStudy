package com.example.a230811_mvvm

import android.view.View
import android.widget.Toast

class Presenter(var viewInterface: ViewInterface){
    //파라미터로 받은 뷰 인터페이스를 현 클래스의 인터페이스에 할당.

    var model = Model() //모델과

    //뷰를 변경하는 코드를 가진다.
    fun clickNumber (i: Int) {
        viewInterface.toastMessage(i)
        model.inputPassword(i)

        if (model.password.size == 4 && model.checkPassword()){
            //모델에 있는 패스워드 리스트 길이가 4이고, 모델의 비밀번호 체크하는 함수가 참일때.
            viewInterface.checkPassWordMessage()
        }
    }
}