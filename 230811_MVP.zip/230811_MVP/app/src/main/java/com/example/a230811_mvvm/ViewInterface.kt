package com.example.a230811_mvvm

interface ViewInterface {
    fun toastMessage(i : Int)
    fun checkPassWordMessage()
}