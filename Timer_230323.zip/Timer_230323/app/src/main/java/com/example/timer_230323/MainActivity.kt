package com.example.timer_230323

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.timer_230323.databinding.ActivityMainBinding
import java.util.*
import kotlin.concurrent.timer


class MainActivity : AppCompatActivity() { //AppCompatActivity() 는 클래스 안에 있어야 사용이 가능, 이것은 생명주기(create,..) 를 사용할 수 있도록 함.

    private var time = 0
    private var timerTask: Timer? = null // 널 값이 없다.


//    lateinit var secTextView: TextView
//    lateinit var milliTextView: TextView
//    lateinit var timerSettingButton: Button
//    lateinit var inputEditText: EditText
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

//        secTextView = findViewById(R.id.secTextView)
//        milliTextView = findViewById(R.id.milliTextView)
//        timerSettingButton = findViewById(R.id.timerSettingButton)
//        inputEditText = findViewById(R.id.inputEditText)
        var inputEditText = binding.inputEditText
        var secTextView = binding.secTextView
        var milliTextView = binding.milliTextView
        var timerSettingButton = binding.timerSettingButton


        binding.timerSettingButton.setOnClickListener {
            if (inputEditText.text.toString().toInt() != 0) {

                time = inputEditText.text.toString().toInt() * 100
                timerTask = timer(period = 10) {

                    time--
                    val sec = time / 100
                    val milli = time % 100
                    runOnUiThread { //메인스레드 (UI조작 가능)
                        // 특정 동작을 스레드에서 ui동작하도록 함
                        // 하지만 현재 스레드가 ui스레드 아니면 취소?
                        secTextView.text = "$sec"
                        milliTextView.text = "$milli"
                    }

                    if (time == 0) {

                        runOnUiThread {
                            secTextView.text = "0"
                            milliTextView.text = "0"
                            timerTask?.cancel() //타이머 취소

                            toast("타이머 종료됨!!")
                        }
                    }
                }
            }
        }
    }

    fun toast(message: String) {
        var s = Toast.makeText(this, message, Toast.LENGTH_SHORT)
        s.show()


    }



}





