package com.example.a230816_b1nd

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView

//데이터랑 어댑터 연결 -> 어댑터가 리사이클러뷰 안의 아이템 뷰랑 연결
class YejinAdapter(
    private val itemList: ArrayList<YejinItem>
) :
    RecyclerView.Adapter<YejinAdapter.YejinViewHolder>() {
    //리사이클러뷰의 어댑터 기능을 재정의 해서 사용.

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): YejinViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recycler_view, parent, false)
        //parent.context : 리사이클러뷰 / 리사이클러뷰에 한 아이템을 담음. //부모 context 내에서 어떤 요소를 찾는가. (부모에 따라 요소가 다르니깐)

        return YejinViewHolder(view)
    }

    //postion : index, 아이템 인덱스.
    //선택했을 때의 포지션을 기억해서 뷰를 보이게 함. (포지션을 기억해 뒤로 갔을 때 다시 1번으로 안가게 하고 싶지만.. 초기화 되는걸 고치지 못했습니다.)
    override fun onBindViewHolder(holder: YejinViewHolder, position: Int) {

        holder.text_lostItem.text = itemList[position].lostItem
        holder.text_name.text = itemList[position].name
        //삭제 버튼을 눌렀을 때, 그떄의 포지션 아이템을 삭제.
        holder.deletebutton.setOnClickListener {
            itemList.remove(itemList[position])
            this.notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return itemList.count()
    }

    inner class YejinViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val text_lostItem = itemView.findViewById<TextView>(R.id.text_lostItem)
        val text_name = itemView.findViewById<TextView>(R.id.text_name)
        val deletebutton = itemView.findViewById<Button>(R.id.delete_btn)
        //포지션을 기억해 뷰를 보이게 하는 onBindHolder 에서 삭제도 관리한다.

        //이 클래스를 생성할 때, 이벤트를 다 등록. / 생성시 아이템뷰에 이벤트 등록
        init {
            itemView.setOnClickListener {
                val bundle = Bundle()
                bundle.putString("text_lostItem", text_lostItem.text.toString())
                bundle.putString("text_name", text_name.text.toString())
                val navController = itemView.findNavController()
                navController.navigate(R.id.action_homeFragment_to_detailFragment, bundle)
                //액션의 아이디를 걸어야 함!
                Log.d("TAG", "눌림")
            }


        }

    }
}
