package com.example.a230816_b1nd

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.example.a230816_b1nd.databinding.FragmentEditBinding


class EditFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentEditBinding.inflate(inflater, container, false)

        binding.addBtn.setOnClickListener {
            val inputLostItem = binding.editLostItem.text.toString()
            val inputName = binding.editName.text.toString()

            if (inputLostItem.isBlank() || inputName.isBlank()) {
                Toast.makeText(requireContext(), "빈 칸을 채워주세요", Toast.LENGTH_SHORT).show()
            } else {
                val bundle = Bundle()
                bundle.putString("input_lostItem", inputLostItem)
                bundle.putString("input_name", inputName)

                val navController = requireView().findNavController()
                navController.navigate(R.id.homeFragment, bundle)

                Toast.makeText(requireContext(), "추가 성공!", Toast.LENGTH_SHORT).show()
            }
        }
        return binding.root
    }
}