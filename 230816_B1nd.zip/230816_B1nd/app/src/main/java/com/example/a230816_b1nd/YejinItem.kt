package com.example.a230816_b1nd

//요소의 구조
data class YejinItem(val lostItem: String, val name: String)

