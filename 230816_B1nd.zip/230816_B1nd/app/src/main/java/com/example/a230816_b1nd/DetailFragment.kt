package com.example.a230816_b1nd

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation.findNavController
import androidx.navigation.findNavController
import com.example.a230816_b1nd.databinding.FragmentDetailBinding
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Date




class DetailFragment : Fragment() {
    //생명주기에 의해 자동적으로 create가 됨.

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentDetailBinding.inflate(inflater, container, false)

        //프래그먼트의 뷰가 생성되기 전에 번들 데이터를 읽으면 arguments가 null을 반환
        with(binding) {
            textDetailLostItem.text = arguments?.getString("text_lostItem").toString()
            textDetailName.text = arguments?.getString("text_name").toString()

            //detail 에서 홈으로 간다는것을 알림
            val bundle = Bundle()
            backBtn.setOnClickListener {
                val navController = requireView().findNavController()
                bundle.putString("naviType", "detail")
                navController.navigate(R.id.homeFragment, bundle)
            }
        }
        val localDate: LocalDate = LocalDate.now()
        binding.textDay.text = localDate.toString()

        return binding.root
    }

}

