package com.example.a230816_b1nd

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    //전역변수 (다른 클래스에서도 사용가능) -> static  (어댑터에 설정하니 계속 프래그먼트를 새롭게 그리면서 리스트가 초기화되어.. 액티비티에 전역으로 설정.)
    companion object{
        var itemList:ArrayList<YejinItem> = arrayListOf()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //기본적으로 가지고 있는 더미 데이터 생성도 여기서.
        for (i in 1..100){
            itemList.add(YejinItem(lostItem = "우산 $i", name = "이예진 $i"))
        }
        setContentView(R.layout.activity_main)
    }

}