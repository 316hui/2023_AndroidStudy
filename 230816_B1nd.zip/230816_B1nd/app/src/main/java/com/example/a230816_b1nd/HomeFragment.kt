package com.example.a230816_b1nd

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.a230816_b1nd.databinding.FragmentHomeBinding



class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        var yejinAdapter = YejinAdapter(MainActivity.itemList)
        with(binding.lostItemPage) {
            adapter = yejinAdapter
            //어떤 어댑터를 쓸지 설정.
            layoutManager = LinearLayoutManager(requireContext())
            //리사이클러뷰 크기를 유연하게 조정
        }

        //분실물 추가 버튼 클릭
        binding.plusBtn.setOnClickListener {

            requireView().findNavController().navigate(R.id.action_homeFragment_to_editFragment)
        }

        var naviGbn = arguments?.getString("naviType")
        //어디서 홈으로 오는지 value를 가져옴


        val inputlostitem = arguments?.getString("input_lostItem")
        val inputname = arguments?.getString("input_name")

        if (naviGbn != "detail") {
            if (!inputlostitem.isNullOrBlank()) {
                MainActivity.itemList.add( YejinItem(lostItem = inputlostitem.toString(), name = inputname.toString()))
                yejinAdapter.notifyDataSetChanged()
                //아이템 리스트뷰가 바뀌었을 때, 리사이클러뷰에게 알림.
            }
        }

        return binding.root
    }
}




