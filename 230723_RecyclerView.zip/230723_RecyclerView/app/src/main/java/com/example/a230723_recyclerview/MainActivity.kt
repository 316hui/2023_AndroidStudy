package com.example.a230723_recyclerview

import android.R
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.a230723_recyclerview.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        <> : 실제 리스트에 저장될 데이터의 타입을 의미
        val rv_board = binding.profile

        val itemList = ArrayList<BoardItem>()


//      !! :  Kotlin에서 Nullable 타입을 Non-Nullable로 강제로 변환하는 연산자. null 값이 아님을 확신.

        itemList.add(BoardItem("이예진", "17세"))
        itemList.add(BoardItem("이예진", "17세"))
        itemList.add(BoardItem("이예진", "17세"))
        itemList.add(BoardItem("이예진", "17세"))
        itemList.add(BoardItem( "이예진", "17세"))
        itemList.add(BoardItem( "이예진", "17세"))
        itemList.add(BoardItem( "이예진", "17세"))
        itemList.add(BoardItem( "이예진", "17세"))

        val boardAdapter = BoardAdapter(itemList)
        boardAdapter.notifyDataSetChanged()

        rv_board.adapter = boardAdapter
        rv_board.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

    }
}