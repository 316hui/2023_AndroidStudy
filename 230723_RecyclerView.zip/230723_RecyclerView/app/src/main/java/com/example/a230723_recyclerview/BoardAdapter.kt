package com.example.a230723_recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.a230723_recyclerview.databinding.ActivityMainBinding


class BoardAdapter(val itemList: ArrayList<BoardItem>) :
    RecyclerView.Adapter<BoardAdapter.BoardViewHolder>() {

//    viewGroup : 다른 뷰들을 포함하는 컨테이너 역할의 클래스. (linearLayout, RelativeLayout, FrameLayout..)
//    context : 액티비티, 서비스 컴포넌트가 이를 상속받음 -> 실행앱 정보, 리소스 접근 ..
//    LayoutInflater : 안드로이드에서 XML 레이아웃 파일을 실제 뷰 객체로 인플레이션하는 역할의 클래스
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BoardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recycler_ex, parent, false)

//        1. R.layout.item_recycler_ex <-를 parent.context에서 인플레이션하여 뷰 객체(view) 생성.
//        2.inflate 세번째 매개변수인 false는 생성된 뷰를 parent에 자동으로 추가하지 않도록 지정함

        return BoardViewHolder(view)

//        BoardViewHolder(각 아이템을 보여줌) 객체를 생성하고 반환.
    }

//    BoardViewHolder : RecyclerView의 각 아이템을 보여주는 역할을 담당.
//    position은 현재 바인딩하고 있는 아이템의 인덱스
    override fun onBindViewHolder(holder: BoardViewHolder, position: Int) {
        holder.tv_age.text = itemList[position].age
        holder.tv_name.text = itemList[position].name
//    ViewHolder의 tv_age라는 TextView의 텍스트를 itemList에서 해당 position에 있는 아이템의 나이(age)로 설정합니다.
    }

//  RecyclerView에 표시할 아이템의 개수를 반환 = 위 클래스에서 매개변수로 받은 itemList 의 길이
    override fun getItemCount(): Int {
        return itemList.count()
    }


    inner class BoardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tv_age = itemView.findViewById<TextView>(R.id.tv_age)
        val tv_name = itemView.findViewById<TextView>(R.id.tv_name)
    }
}
