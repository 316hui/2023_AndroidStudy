package com.example.a230723_recyclerview

import android.graphics.drawable.Drawable

data class BoardItem(val name: String, val age: String)

